package com.datatransforming.baseapp.presenter;

import java.util.List;

import com.datatransforming.baseapp.entity.User;
import com.datatransforming.baseapp.presenter.ouput.UserDataTable;

public interface UserPresenter {


	public List<UserDataTable> getUserDataTable(List<User> users);
	
}

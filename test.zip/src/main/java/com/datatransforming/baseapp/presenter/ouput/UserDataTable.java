package com.datatransforming.baseapp.presenter.ouput;

import java.util.List;

import com.datatransforming.baseapp.entity.Category;
import com.datatransforming.baseapp.entity.User;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDataTable {

	private Integer id;
	
	private String userName;
	
	private String fullName;
	
	private String email;

	private String type;
	
	private String status;
	
	private String address;
	

	
	public UserDataTable(User user, List<Category> categoryList){
		this.id=user.getId();
		this.userName=user.getUserName();
		this.fullName=user.getFirstName() + " " + user.getLastName();
		this.email=user.getEmail();
		this.address=user.getAddress();
		for(Category cat:categoryList) {
			if (cat.getId()== user.getUserType()) {
				this.type=cat.getValue();
				continue;
			}
			if(cat.getId()==user.getStatus()) {
				this.status=cat.getValue();
			}		
		}		
	}
	
}

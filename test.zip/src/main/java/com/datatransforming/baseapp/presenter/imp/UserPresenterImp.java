package com.datatransforming.baseapp.presenter.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.datatransforming.baseapp.common.CategoryGroupName;
import com.datatransforming.baseapp.entity.Category;
import com.datatransforming.baseapp.entity.User;
import com.datatransforming.baseapp.presenter.UserPresenter;
import com.datatransforming.baseapp.presenter.ouput.UserDataTable;
import com.datatransforming.baseapp.repository.CategoryRepository;

@Component
public class UserPresenterImp implements UserPresenter{

	@Autowired
	private CategoryRepository categoryRepo;
	
	@Override
	public List<UserDataTable> getUserDataTable(List<User> users) {
		
		List<UserDataTable> returnList=new ArrayList<UserDataTable>();
		List<Category> userCategoryList=new ArrayList<Category>();
		userCategoryList.addAll(categoryRepo.findByCategoryGroup(CategoryGroupName.USER_TYPE));
		userCategoryList.addAll(categoryRepo.findByCategoryGroup(CategoryGroupName.USER_STATUS));		
		for(User user:users) {
			returnList.add(new UserDataTable(user, userCategoryList));
		}
		
		return returnList;
	}

}

package com.datatransforming.baseapp.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.datatransforming.baseapp.entity.User;
import com.datatransforming.baseapp.presenter.UserPresenter;
import com.datatransforming.baseapp.presenter.ouput.UserDataTable;
import com.datatransforming.baseapp.repository.UserRepository;
import com.datatransforming.baseapp.service.UserService;

@Component
public class UserServiceImp implements UserService{
	
	@Autowired
	private UserPresenter presenter;
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<UserDataTable> getUserList() {	
				
		return presenter.getUserDataTable((List<User>) userRepository.findAll());
	}

}

package com.datatransforming.baseapp.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.datatransforming.baseapp.presenter.ouput.UserDataTable;

@Component
public interface UserService {

	public List<UserDataTable> getUserList();
}

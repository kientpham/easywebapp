package com.datatransforming.baseapp.common;

public class CategoryGroupName {

	public static String USER_TYPE="USER_TYPE";
	
	public static String USER_STATUS="USER_STATUS";
}

class TableClass{
	
		constructor(){			
		}
		set type(value){
			this._type=value;
		}
		set tableId(value){
			if (value.includes("#")){
				this._tableId=value;	
			}else{
				this._tableId="#"+value;
			}			
		}
		set getTableData(value){
			this._getTableData=value;
		}
		set deleteController(value){
			this._deleteController=value;
		}		
		set editFormObj(value){
			this._editFormObj=value;
		}
		set jsonObj(value){
			this._jsonObj=value;
		}
		set bFilter(value){
			this._bFilter=value;
		}
		set bPaginate(value){
			this._bPaginate=value;
		}
		set order(value){
			this._order=value;
		}
		set displayIfNoData(value){
			this._displayIfNoData=value;
		}
		set buttonAddId(value){
			this._buttonAddId=value;
		}
	
		set divTableData(value){
			if (value.includes("#")){
				this._divTableData=value;	
			}else{
				this._divTableData="#"+value;
			}
		}			
		show(){
			$(this._divTableData).removeClass("hide");
		}		
		hide(){
			$(this._divTableData).addClass("hide");
		}
		
		loadTable(){	
		
			if($('iconloading')!=null){
				 $('body').append('<div class="loadingProcess" id="iconloading"></div>');
			}			
			if($('edit-container')!=null){
				 $('body').append('<div id="edit-container" class="modal-container"></div>');
			}
			if(this._editFormObj!=null ){				
				$('#edit-container').load(this._editFormObj._editFormHtml);
			}
			
			if(this._buttonAddId!=null){			
					$(this._buttonAddId).click({editForm:this._editFormObj},callAddForm);
			}			
			this.callAjax(this);		
		}	
		
		callAjax(tableObj){
			var getTableData =this._getTableData;
			var type =this._type;
			var jsonObj= this._jsonObj;
			$.ajax({
				type : "GET",
				url : getTableData, 
				contentType : "application/json; charset=utf-8",
				async: false,
				dataType : "json",
				data: JSON.stringify(jsonObj),
				beforeSend : function() {
					$("body").addClass("loading");
				},
				success : function(data) {
					if (data.length==0 && displayIfNoData==false){
						$(dataTableName).addClass("hide");
					}else if(data.length>0) {
						var rowDataSet = getDataRow(data);
						var dynamicColumn=getDataColumn(data,type);						
						buildTable(tableObj,dynamicColumn,rowDataSet);
				    }					
				},
				error: function(jqXHR, exception) {					
					showErrorMessage();
				},
				complete: function() {					
					$("body").removeClass("loading");					
				}
			});
		} // End call Ajax method

		deleteRecord(listId){						
			var deleteController= this._deleteController;
			$.ajax({
				type : "POST",
				url : deleteController, 
				data: JSON.stringify(listId),
				async: false,
				contentType : "application/json; charset=utf-8",
				success : function(data) {					
					//showInformationDialog("Message",data);
				},
				error: function (jqXHR, exception) {
					showErrorMessage();
					return false;
		        },
				complete: function () {		
									
					$("body").removeClass("loading");
				}
			});
			this.loadTable();
			return true;
		}
		
		deleteRecords() {			
			var selected = this.getAllSeleted();			
			deleteRecord(selected, this._deleteController)
		}
		
		saveRecord(){
			if(this._editFormObj.saveRecord()){				
				this.loadTable();	
			}
		}
		
		getAllSeleted(){
			var selected = [];
			var allPages = $(this._tableId).DataTable().cells().nodes();
			$(allPages).find('input[type="checkbox"]:checked').each(function() {
			    selected.push($(this).attr('id'));
			});
			
			return selected;
		}

}
//End of Table Class
//-------------------------------------------

class EditForm{
	constructor(){		
	}
	
	set idFieldName(value){
		this._idFieldName=value;
	}
	set editForm(value){
		this._editForm=value;
	}
	set getDropDownValue(value){
		this._getDropDownValue=value;
	}
	set getValuesToBind(value){
		this._getValuesToBind=value;
	}	
	set getDataObjectForUI(value){
		this._getDataObjectForUI=value;
	}
	set saveDataObject(value){
		this._saveDataObject=value;
	}	
	set datePickerList(value){
		this._datePickerList=value;
	}	
	set suggestionList(value){
		this._suggestionList=value;
	}		
	set dataTableListObj(value){
		this._dataTableListObj=value;
	}
	set editFormHtml(value){
		this._editFormHtml=value;
	}
	
	openAddModal(){
		alert('adding');
		this.openEditModal(0);
	}
	
	openEditModal(recordId){
		alert(recordId);
		$(this._editForm).modal("show");
		this.openEditForm(recordId);
	}
	
	openEditForm(recordId) {		
		this.initiateForm();
		if (this._idFieldName==null){
			this._idFieldName="id";
		}
		this.getValue(this._idFieldName,this._getValuesToBind, recordId);
		if (this._dataTableListObj!=null){
			var jsonObj="{"+this._idFieldName+":"+recordId+"}";
			this.loadAllTables(jsonObj);	
		}		
	}
	
	initiateForm(){
		this.handleFormSubmit(this._editForm);	

		if($(this._editForm).tagName=='Form'){			
			this.handleFormSubmit(this._editForm);	
		}		
		if(this._getDropDownValue!=null){
			this.bindDropDownValue(this._getDropDownValue);
		}		
		if(this._datePickerList!=null){
			this.bindDatePicker(this._datePickerList);
		}		
		if (this._suggestionList!=null){
			this.bindSuggestion(this._suggestionList);
		}			
	}	
	
	search(){
		if(!$(this._editForm)[0].reportValidity()){		    		
			 return false;
		 }
		var jsonObj=this.getDataObj(this._idFieldName,this._getDataObjectForUI);
		this.loadAllTables(jsonObj);
	}
	
	loadAllTables(jsonObj){
		for(var i=0;i<this._dataTableListObj.length;i++){
			this._dataTableListObj[i].jsonObj=jsonObj;
			this._dataTableListObj[i].loadTable();	
			this._dataTableListObj[i].show();
		}
	
	}
	
	handleFormSubmit(editForm){
		  $(editForm).submit(function(event){
			  event.preventDefault();		  
		  });
	}
	
	bindDropDownValue(getDropDownValue){	
		$.ajax({
			type : "GET",
			url : getDropDownValue, 
			contentType : "application/json; charset=utf-8",
			dataType : "json",
			success : function(response) {
				var len = response.length;
	            for(var i=0; i<len; i++){                
	            	var controlid = response[i].controlId;            	
	            	var dropdown = document.getElementById(controlid);
	            	if (dropdown!=null){
	            		var ddloption =  dropdown.options;
	            		var isExists = false;
	            		for(var j = 0; j < ddloption.length; j++){            			
	            			if(ddloption[j].value == response[i].value){            			 
	            				isExists=true;            	
	            				break;
	            		    }
	            		}
	            		if (isExists===false){
	            			$(dropdown).append('<option value="' + response[i].value + '">' + response[i].text + '</option>');
	            		}
	            	}
	            }
			},				
			error: function(event, status, xhr) {		
				showErrorMessage();
			}
		});
	}

	bindDatePicker(datePickerList) {
		for (var controlId in datePickerList){		
			$(datePickerList[controlId]).datepicker({
				showOn:"button",
				   	buttonImage: "images/Calendar-icon.png",
				   	buttonImageOnly: true,
				   	changeMonth: true,
			      	changeYear: true
			});
		}
	}
	
	bindSuggestion(suggestionList){	
		for(var i=0;i<suggestionList.length;i++){
			var controlId=suggestionList[i][0];
			var category =suggestionList[i][1];
			var minCharToSuggest=suggestionList[i][2];
			var isMulti=suggestionList[i][3];
			
			var cache = {};
			$(controlId).keyup(function(event){
			}).autocomplete({
		        minLength: minCharToSuggest,
		        source: function( request, response ) {
		        	var value = $(controlId).val()
		        		if(isMulti){
		        			value =extractLast($(controlId).val());            
		        		}
		            if ( value in cache ) {
		            	response( $.ui.autocomplete.filter(
		            			cache[ value ].slice(0, 10), extractLast( request.term ) ) );
		                 return;
		            }        	      	
			        $.ajax({
			        		type: "GET",
			                url: encodeURI("suggestion?searchKey="+ value +"&searchCat=" + category),
			                contentType: "application/json; charset=utf-8",
			                dataType: "json",
			                success: function (data) {           
			                    cache[ value ] = data;	        
			                	response( $.ui.autocomplete.filter(
			                            data.slice(0, 10), extractLast( request.term ) ) );
			                },
			                error: function(event, status, xhr) {
			              }
			        	});        	
		        },
		        focus: function() {
		          return false;
		        },
		        select: function( event, ui ) {
		        	if(isMulti){
			          var terms = split( this.value );
			          terms.pop();
			          terms.push( ui.item.value );
			          terms.push( "" );
			          this.value = terms.join( ", " );
			          return false;
		        	}
		        	else{
		        		return true;
		        	}          
		        }        
			});
		}
	}
	
	getValue(idFieldName,getValuesToBind,recordId){		
		$.ajax({
			type : "POST",
			url : getValuesToBind,
			contentType : "application/json; charset=utf-8",
			data : idFieldName + "=" +recordId,
			beforeSend : function() {
				$("body").addClass("loading");
			},
			success : function(result) {		
				 var columnsIn = result;			 
			        for(var key in columnsIn){		 
			        	var control= document.getElementById(key);
			        	if (control !=null){
			        		if (control.type ==="checkbox"){		        			
			        			control.checked=columnsIn[key];
			        		}else{
			        			control.value=columnsIn[key];
			        		}		        		
			        	}		            
			        } 
			},
			error: function(event, status, xhr) {	
				alert(xhr);
				showErrorMessage();
			},
			complete: function(data, textStatus, xhr) {
				$("body").removeClass("loading");
			}
		});	
	}	
		
	saveRecord(){		
		 if(!$(this._editForm)[0].reportValidity()){		    		
			 return false;
		 }
		 var jsonObj=this.getDataObj(this._idFieldName,this._getDataObjectForUI);	 
		 this.saveDataObj(this._editForm,jsonObj,this._saveDataObject);		 
		 return true;
	}
	
	getDataObj(idFieldName,getDataObjectForUI){
		var jsonObj;
		$.ajax({
			type : "GET",
			url : getDataObjectForUI, 
			dataType : "json",
			async: false,
			contentType : "application/json; charset=utf-8",
			data : idFieldName +"="+0,
			beforeSend : function() {
				$("body").addClass("loading");
			},
			success : function(columnsIn) {	 
			        for(var key in columnsIn){
			        	var control= document.getElementById(key);
			        	if (control !=null){
			        		if (control.type ==="checkbox"){		        			
			        			columnsIn[key]=control.checked;
			        		}else{
			        			columnsIn[key]=control.value;
			        		}		        		
			        	}		            
			        } 		        
			        jsonObj=columnsIn;			    	
			},
			error: function(event, status, xhr) {
				showErrorMessage();
			}
		});	
		return jsonObj;
	}
	
	saveDataObj(editForm, jsonObj,saveDataObject){
		if (jsonObj!=null){
			$.ajax({
	    		type : "POST",
	    		url : saveDataObject,		    	
	    		dataType : "json",
	    		async: false,
	    		data: JSON.stringify(jsonObj),
	    		contentType : "application/json; charset=utf-8",
	    		success : function(response) {		
	    			if(response["msg"] == '') {		    
	    				showInformationDialog("Message", "The record has been saved successfully!");
	    				$(editForm).modal("hide");	    				
	    			} else {
	    				showInformationDialog("Message", response);
	    			}
	    		},
	    		error: function (jqXHR, textStatus, errorThrown) {	
	    			alert(jqXHR.responseText);  		    			    		    
	    		},		
	    		complete: function(data, textStatus, xhr) {		    		
	    			$("body").removeClass("loading");
	    		}
	    	});
		}
	}
}
//End of EditForm Class
//--------------------------------------------

function getDataColumn(data,type){
	var dynamicColumns = [];			
    var i = 0;
    $.each(data[0], function (key, value) {
        var obj;// = { sTitle: key };       
        dynamicColumns[i] = obj;
        i++;
    });	
    
    if(type==null){
		dynamicColumns[0]= {
             	"render": function ( ddata, type, row ) {
             		var id = row[0];
             		return '<input type="hidden" class="hide" name="touchbutton" id='+id+' value='+id+'>';
             	},
             	"orderable": false,
             	"visible":false
             };    		
		
    }else{
    	
    	switch (type){
    		case "edit":
    			dynamicColumns[0]= {
                 	"render": function ( ddata, type, row ) {
                 		var id = row[0];
                 		return '<input type="hidden" class="hide" name="touchbutton" id='+id+' value='+id+'>';
                 	},
                 	"orderable": false,
                 	"visible":false
                 };  
	    		dynamicColumns[i]= {"render" : function(data,type,item,meta) {				
	    			var str =  item.id;
	    			return '<a href="#" id="btnEdit" ><span class="glyphicon glyphicon-edit"></span></a>';
	    		},
	    		sClass: "alignCenter",
	    		"orderable": false
	    		}
	    		dynamicColumns[i+1]= {"render" : function(data,type,item,meta) {				
	    			var str =  item.id;
	    			return '<a href="#" id="btnEdit" ><span class="glyphicon glyphicon-remove"></span></a>';
	    		},
	    		sClass: "alignCenter",
	    		"orderable": false
	    		}
	    		break;
    		case "checkbox":
    			dynamicColumns[0]={
    				"render" : function(ddata, type, row ) {
    					var id = row[0];
    					return '<input type="checkbox" name="id[]" class="chkBox" id="'+ id +'" >';
    					},
    					"orderable": false
    			};	    		
    			break;
    		case "radio":
    			dynamicColumns[0]= {
                 	"render": function ( ddata, type, row ) {
                 		var id = row[0];
                 		return '<input type="radio" class="singleRadio" name="touchbutton" id='+id+' value='+id+'>';
                 	},
                 	"orderable": false
                 };
    			break;
    	}
    	
    	
    }
	return dynamicColumns;
}

function getDataRow(data){         
    
    var rowDataSet = [];
    var i = 0;
    $.each(data, function (key, value) {
        var rowData = [];
        var j = 0;
        $.each(data[i], function (key, value) {
            rowData[j] = value;
           
            j++;
        });
        rowDataSet[i] = rowData;
        i++;
    });
    return rowDataSet;
}

function buildTable(tableObj, dynamicColumns,rowDataSet){

	var table=$(tableObj._tableId);    
    var bFilter =tableObj._bFilter;
    if (bFilter==null){
    	bFilter=true;
    }
    var bPaginate=tableObj._bPaginate;
    if (bPaginate==null){
    	bPaginate=true;
    }
    var order=tableObj._order;
    var ordering =false;
    if(order!=null){
    	ordering=true;    	
    }else {
    	order=1;
    }    
    var dataTable=table.DataTable({
	"ordering" : ordering,
	"order": [[ order, "asc" ]],
	"bPaginate" : bPaginate,
	//"bLengthChange" : false,
	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	"bAutoWidth": false,
	"bFilter" : bFilter,
	"bInfo" : true,	
    "aaData": rowDataSet,
    "aoColumns": dynamicColumns,
    "responsive": true,
    "retrieve": true
    });    
    var editFormObj= tableObj._editFormObj;
	if(editFormObj!=null){
		table.on('click', 'tr', function (evt) {			
	    	var $cell=$(evt.target).closest('td');	    	
	        if( $cell.index()==dynamicColumns.length-3){	        	
	        	var data = table.DataTable().row( this ).data();	        	
	        	editFormObj.openEditModal(data[0]);
        	}
	        if( $cell.index()==dynamicColumns.length-2){	        	
	        	var data = table.DataTable().row( this ).data();
	        	callDeleteDialog(data[0],tableObj);	        	
        	}
    	});	       
	}	
	if ($('#checkAll')!=null){
	    $('#checkAll').on('click', function(){
	       var rows = table.DataTable().rows({ 'search': 'applied' }).nodes();
	       $('input[type="checkbox"]', rows).prop('checked', this.checked);
	    });	
	    table.on('change', 'input[type="checkbox"]', function(){
	       	if(!this.checked){
					$("#checkAll").prop("checked",false);
	       	} 
	       	if (table.DataTable().$(".chkBox:checked", { "page": "all" }).length == table.DataTable().rows().data().length){
	            $("#checkAll").prop('checked', true);
	        }
	    });  
	}		
	dataTable.clear().draw();
	dataTable.rows.add(rowDataSet).draw();
}

function showInformationDialog(title,message){
	doModal(title,message,"");
}

function cancelProcess() {
	$("body").removeClass("loading");
}

function showErrorMessage(){	
	showInformationDialog("Error Message","Sorry, an error has occurred! Please contact Administrator to troubleshoot.");
}

function extractLast( term ) {
    return split( term ).pop();
  }

function split( val ) {
    return val.split( /,\s*/ );
}

function callAddForm(event){
	
	event.data.editForm.openAddModal();
}

function callDeleteDialog(id,tableObj){
	doModal("Confirmation","Are you sure to delete this record?","Confirm");
	if ($("#btnSubmit")!=null){
		$("#btnSubmit").click({id:id,tableObj:tableObj},function(event){						
			var listId=[];
			listId.push(event.data.id);
			event.data.tableObj.deleteRecord(listId);
			$("#dynamicModal").modal('toggle');
		});
	}	
}

function doModal(heading, formContent,btnText) {
    html =  '<div id="dynamicModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="confirm-modal" aria-hidden="true">';
    html += '<div class="modal-dialog">';
    html += '<div class="modal-content">';
    html += '<div class="modal-header">';
    html += '<a class="close" data-dismiss="modal">×</a>';
    html += '<h4>'+heading+'</h4>'
    html += '</div>';
    html += '<div class="modal-body" align="center">';
    html += formContent;
    html += '</div>';
    html += '<div class="modal-footer">';
    if (btnText!='') {
        html += '<span id="btnSubmit" class="btn btn-success"';
        html += '">'+btnText+'</span>';
    }
    html += '<span class="btn btn-primary" data-dismiss="modal">Close</span>';
    html += '</div>';  // content
    html += '</div>';  // dialog
    html += '</div>';  // footer
    html += '</div>';  // modalWindow
    $('body').append(html);
    $("#dynamicModal").modal();
    $("#dynamicModal").modal('show');	
    
    $('#dynamicModal').on('hidden.bs.modal', function (e) {
        $(this).remove();
    });
}

$(document).ajaxError(function(event, jqXHR, ajaxSettings, thrownError) {
	if (undefined != jqXHR.responseText && "" != jqXHR.responseText && jqXHR.status == 200) {
		showErrorMessage();
		return;
	} 
});

